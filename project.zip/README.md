# mern-project-template-SSLlab-monsoon2025
This is the template created for MERN project for SSL Lab in Moonsoon 2025 for MTech First year student 

## Team Contributions
- Setup for Nishant completed on October 17, 2025. Ready for the challenge!